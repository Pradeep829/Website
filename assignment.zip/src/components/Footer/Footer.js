import React from "react";
import data from "../../data/data";
import Styles from './footer.module.css'
function Footer() {
  return (
    <div className={Styles.footer}>
      <div className={Styles.footer_content1}>{data.footer.footercontent1}</div>
      <div className={Styles.footer_content2}>{data.footer.footercontent2}</div>
      <div className={Styles.footer_content3}>{data.footer.footercontent3}</div>
      <div className={Styles.footer_content4}>{data.footer.footercontent4}</div>
    </div>
  );
}

export default Footer;
