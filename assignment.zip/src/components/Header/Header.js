import React, { useState } from "react";
import { ReactComponent as Logo } from "../../assets/svg/logo.svg";
import Styles from "./header.module.css";

function Header({ onNavigate, headerList, selected }) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const closeHandler = () => {
    setIsMenuOpen(false);
  }
  return (
    <header>
      <div className={Styles.header_main}>
        <div className={Styles.header_wrapper}>
        <Logo className={Styles.logo} />

          <div className={Styles.header_mobile}>
            {" "}
            <Logo className={Styles.logo_mobile} />
            <div className={Styles.hamburger} onClick={toggleMenu}>
              <div className={Styles.bar}></div>
              <div className={Styles.bar}></div>
              <div className={Styles.bar}></div>
            </div>
          </div>

          <div
            className={`${Styles.header_list} ${isMenuOpen ? Styles.open : ""}`}
          >
            <div className={Styles.close_icon_mobile} onClick={closeHandler}>X</div>
            {headerList.map((item, index) => (
              <div
                className={
                  selected === item
                    ? `${Styles.header_item} ${Styles.selected}`
                    : Styles.header_item
                }
                key={index}
                onClick={() => {
                  onNavigate(item);
                  setIsMenuOpen(false);
                }}
              >
                {item}
              </div>
            ))}
          </div>
        </div>
      </div>
    </header>
  );
}

export default Header;
