import React from 'react'
import data from '../../../data/data'
import Styles from './personaldetails.module.css'
function PersonalDetails() {
  return (
    <div className={Styles.personaldetails}>
      <div className={Styles.wrapper}>
      <h1 className={Styles.heading}>{data.personaldetails.heading}</h1>
      <div className={Styles.input_wrapper}>
      <input type="text" className={Styles.input} placeholder={data.personaldetails.placeholder1}/>
      <input type="number" className={Styles.input} placeholder={data.personaldetails.placeholder2}/>
      <textarea type="text" className={Styles.textareainput} placeholder={data.personaldetails.placeholder3}/>
      </div>
      </div>

    </div>
  )
}

export default PersonalDetails