import React, { useState } from "react";
import Header from "../Header/Header";
import Footer from "../Footer/Footer";
import Accordian from "../Accordian/Accordian";
import Styles from "./homepage.module.css";
import ContactUs from "../Homepage/ContactUs/ContactUs";
import OurTeam from "../Homepage/OurTeam/OurTeam";
import PersonalDetails from "../Homepage/PersonalDetails/PersonalDetails";

function Homepage() {
  const components = {
    "Our Team": <OurTeam />,
    "Personal Details": <PersonalDetails />,
    "Contact Us": <ContactUs />,
  };

  const [accordianItems, setAccordianItems] = useState([
    "Personal Details",
    "Contact Us",
  ]);

  const [selectedItem, setSelectedItem] = useState("Our Team");

  const handleSelection = (item) => {
    setAccordianItems((prevItems) => {
      const newItems = prevItems.filter((i) => i !== item);
      if (selectedItem !== null) {
        newItems.push(selectedItem);
      }
      setSelectedItem(item);
      return newItems;
    });
  };

  return (
    <div className={Styles.homepage}>
      <Header
        onNavigate={handleSelection}
        headerList={Object.keys(components)}
        selected={selectedItem}
      />
      <div className={Styles.homepage_main}>
        <div className={Styles.accordian}>
          <Accordian
            sidebaraccordian={accordianItems}
            onSelect={handleSelection}
            components={components}
            selectedItem={selectedItem}
          />
        </div>
      </div>
      <Footer />
    </div>
  );
}

export default Homepage;