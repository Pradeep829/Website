import React from 'react'
import data from '../../../data/data'
import Styles from "./contactus.module.css"
function ContactUs() {
  return (
    <div className={Styles.contactus}>
      <div className={Styles.wrapper}>
      <h1 className={Styles.heading}>{data.contactus.heading}</h1>
      <div className={Styles.description}>{data.contactus.description}</div>
      </div>
    </div>
  )
}

export default ContactUs