import React from "react";
import Marquee from "react-fast-marquee";
import data from "../../../data/data";
import Styles from "./ourteam.module.css";
import './ourteam.css'
function OurTeam() {
  return (
    <div className={Styles.ourteam}>
      <div className={Styles.ourteam_wrap}>
        <div className={Styles.wrapper}>
          <h1 className={Styles.heading}>{data.ourteam.heading}</h1>
          <div className={Styles.description1}>{data.ourteam.description1}</div>
          <div>{data.ourteam.description2}</div>
        </div>
        <div className={Styles.infinite_scroll}>
          <Marquee speed={50} gradient={false} className='infinite-scroller' >
            {data.ourteam.swiper.map((item, index) => (
              <div className={Styles.swiper_img_wrapper} key={index}>
                <img src={item.imgsrc} alt={item.imgsrc} />
                <div>{item.name}</div>
                <div>{item.role}</div>
              </div>
            ))}
          </Marquee>
        </div>
      </div>
    </div>
  );
}

export default OurTeam;
