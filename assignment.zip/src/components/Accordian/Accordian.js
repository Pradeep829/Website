import React from "react";
import Styles from "./accordian.module.css";

function Accordian({ sidebaraccordian, onSelect, components, selectedItem }) {
  return (
    <div className={Styles.right_accordian}>
      {[...sidebaraccordian, selectedItem].map((item, index) => (
        <div
          className={`${Styles.accordian_title_main} ${
            item === selectedItem ? Styles.component : Styles.list
          } ${
            item === "Our Team"  ? Styles.ourteam : ""
          }
          ${
            item === "Personal Details"
              ? Styles.personaldetails
              : ""
          }
          ${
            item === "Contact Us" 
              ? Styles.contactdetails
              : ""
          }`}
          key={index}
          onClick={() =>
            item && sidebaraccordian.includes(item) && onSelect(item)
          }
        >
          {item === selectedItem ? (
            <div className={Styles.component_wrapper}>{components[item]}</div>
          ) : (
            <div className={`${Styles.accordian_title} `}>{item}</div>
          )}
        </div>
      ))}
    </div>
  );
}

export default Accordian;
