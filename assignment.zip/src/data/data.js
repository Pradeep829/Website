const data = {
  header: [
    { id: 1, name: "OUR TEAM" },
    { id: 2, name: "PERSONAL DETAILS" },
    { id: 3, name: "CONTACT US" },
  ],
  ourteam: {
    heading: "Our Team",
    description1:
      "We believe that great ideas come to life through collaboration and innovation. Our team is a diverse group of passionate professionals, each bringing unique skills and experiences to the table. From creative designers and strategic thinkers to technical experts and problem-solvers, we are united by a shared vision of delivering excellence in everything we do.",
    description2:
      "Our mission is to empower businesses and individuals by creating innovative, sustainable, and user-friendly designs. With a culture that values integrity, growth, and teamwork, we are committed to creating meaningful solutions that make a difference. Whether it’s crafting cutting-edge designs, developing user-centered interfaces, or building sustainable solutions, our team thrives on turning challenges into opportunities.",

    swiper: [
      {
        id: 1,
        name: "Meredith Allen",
        imgsrc: require('../assets/jpg/ceo.jpg'),
        role: "CEO",
      },
      {
        id: 2,
        name: "Thomas Woodward",
        imgsrc: require('../assets/jpg/coo.jpg'),
        role: "COO",
      },
      {
        id: 3,
        name: "Wade Barton",
        imgsrc: require('../assets/jpg/businessanalyst.jpg'),
        role: "Business Analyst",
      },
      {
        id: 4,
        name: "Yahir Marquez",
        imgsrc: require('../assets/jpg/marketingexecutive.jpg'),
        role: "Marketing Executive",
      },
      {
        id: 5,
        name: "Vera Rodgers",
        imgsrc: require('../assets/jpg/leaddesigner.jpg'),
        role: "Lead Designer",
      },
    ],
  },

  personaldetails: {
    heading: "Personal Details",
    placeholder1: "Enter your Name",
    placeholder2: "Enter your Mobile Number",
    placeholder3: "Enter your Address",
  },

  contactus: {
    heading: "Contact Us",
    description:
      "We are a team of engineers, communication experts and innovators who specialise in developing technology propositions for the world around us. We noticed that in an overwhelming number of use cases, technology was not really the problem; mistrust came from how it was deployed by creators and then understood and used by consumers.",
  },

  footer: {
    footercontent1: "We've got one planet--let's treat it right.",
    footercontent2: "2025 Company Name",
    footercontent3: "Privacy Policy",
    footercontent4: "Terms & Conditions",
  },
};

export default data;